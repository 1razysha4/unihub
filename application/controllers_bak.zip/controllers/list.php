<?php defined('BASEPATH') or die('Direct access is not allowed');
class Lists  extends Public_Controller{
	function __construct(){
		parent::__construct();
	}
	function index(){
		
	}
}
?>