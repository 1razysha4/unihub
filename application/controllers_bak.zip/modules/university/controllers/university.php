<?php 
if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class University extends MX_Controller{
	function __construct(){
		parent:: __construct();
		$this->load->model('university/university_model');
		$this->load->library('template');
	}

	function index(){
		$slug = $this->uri->segment(2);
		$data = $this->university_model->getId($slug);
		if(is_array($data))
		$id = $data[0]['university_id'];
		$universitydata = $this->university_model->getUniversityData($id);

		$data = array(
			'recordData' 	=> $universitydata,
			'title'			=> "University"
 		);

		$this->load->view('university/page',$data);
	}
};