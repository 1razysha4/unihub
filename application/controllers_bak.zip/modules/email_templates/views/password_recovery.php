Your password has been reset successfully .<br>
New Password:<?php echo $password; ?><br />
Login : <a href="<?php echo site_url();?>login"><?php echo site_url();?>login</a>

