<?php defined('BASEPATH') or die('Direct access script is not allowed');
$lang['menu']='Menu';
$lang['menus']='Menus';