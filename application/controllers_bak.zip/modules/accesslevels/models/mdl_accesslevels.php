<?php defined('BASEPATH') or die('Direct access is restricted');
class Mdl_Aaccesslevels extends MY_Model{
	function __construct(){
		parent::__construct();
	}
}

?>