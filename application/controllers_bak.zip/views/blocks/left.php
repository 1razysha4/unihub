<?php (defined('BASEPATH')) OR exit('No direct script access allowed');?>
                <div class="col1">
                	<div id="side-menu" style="">
                    	<h2 class="dotted">Useful Links</h2>
                    <ul>
                        <li style="border:none; padding-top:15px;"><a href="http://www.fafsa.ed.gov/" target="_blank">FAFSA</a></li>
                        <li><a href="http://www.collegeboard.org/" target="_blank">College Board</a></li>
                        <li><a href="http://www.college.gov/" target="_blank">College.gov</a></li>
                        <li><a href="http://www.collegenet.com/" target="_blank">College Net</a></li>
                        <li><a href="http://www.ed.gov/" target="_blank">Ed.gov</a></li>
                        <li><a href="http://www.studentaid.ed.gov/" target="_blank">Student Aid</a></li>
                        <li><a href="http://www.finaid.org/" target="_blank">Fin Aid</a></li>
                         <li><a href="http://www.osfa.mass.edu/" target="_blank">OSFA</a></li>
                    </ul>
                    </div>
                    
                   
                    </div>