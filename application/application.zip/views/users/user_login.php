<?php
if($this->input->is_ajax_request()==1)
{
	$user_id = $this->session->userdata('user_id');
	if((int)$user_id==0){		
		echo $this->load->view('users/check_login_session');
		return '';
	}
	die();
}
?> 
<script type="text/javascript">
	$(document).ready(function(){
	var validator2 = $("#login-form").validate({
		errorPlacement: function(error, element) {
			$( element )
				.closest( "form" )
					.find( "label[for='" + element.attr( "id" ) + "']" )
						.append( error );
		},
		errorElement: "span",
		rules: {
			email: {
				required: true,
				email: true
			},
			password: {
				required: true
			}
		},
		messages: {
			email: {
				required: " (required)",
			},
			password: {
				required: " (required)"
			}
		}
	});
})
</script>
            <div class="grid_24">
                    <!--Start Cotent-->
                    <div class="content">
                        <h1 class="page_title"></h1>
                            <h1>Sign in or Create a new Account</h1>
    <div id="loginform">
        <?php echo form_open('','class="loginform" id="login-form"');?>
            <h1 class="form_tag">Sign In</h1>
            <div class="label">
                <label for="email">Email-id<span class="required">*</span></label>
            </div>
            <div class="row">
                <input type="text" name="email" id="email" value="" />
            </div>
            <div class="label">
                <label for="password1">Password<span class="required">*</span></label>
            </div>
            <div class="row">
                <input type="password" name="password" id="password1"/>
            </div>
            <input class="submit" type="submit" name="login" value="Log In"/>
            <a href="<?php echo site_url('password-recovery')?>" class="forgot_password" >Lost your password?</a>
<input type="hidden" name="return" value="<?php echo $this->input->get('return');?>"  />
         </form>	
    </div>  
    <script>
// only for demo purposes
$(document).ready(function() {
	// validate the form when it is submitted
	var validator = $("#registerform").validate({
		errorPlacement: function(error, element) {
			// Append error within linked label
			$( element )
				.closest( "form" )
					.find( "label[for='" + element.attr( "id" ) + "']" )
						.append( error );
		},
		errorElement: "span",
		rules: {
			password: {
				required: true,
				minlength: 5
			},
			cpassword: {
				required: true,
				minlength: 5,
				equalTo: "#password"
			},
			email_address: {
				required: true,
				email: true
			},
			agree: "required"
		},
		messages: {
			user_name: {
				required: " (required)",
				minlength: " (must be at least 3 characters)"
			},
			password: {
				required: " (required)",
				minlength: " (must be between 5 and 12 characters)",
				maxlength: " (must be between 5 and 12 characters)"
			},
			cpassword: {
				required: "Please provide a password",
				minlength: "Your password must be at least 5 characters long",
				equalTo: "Please enter the same password as above"
			},
			email_address: {
				required: " (required)"
			},
			agree: "Please accept our terms and conditions."
		}
	});

	$(".cancel").click(function() {
		validator.resetForm();
	});
});
</script>
        <div id="register">
            <h1 class="form_tag">Create a free Account</h1>
<?php echo form_open(site_url('register'),'id="registerform" class="registerForm" name="registration"'); ?>
                <div class="label">
                    <label for="username">Username<span class="required">*</span></label>
                </div>
                <div class="row">
                    <input type="text" name="user_name" id="username" required value="<?php echo set_value('user_name'); ?>"/>
                    <p id="user_error"></p>
                </div>
                <div class="label">
                    <label for="email_address">Email<span class="required">*</span></label>
                </div>
                <div class="row">
                    <input type="text" name="email_address" id="email_address" required value="<?php echo set_value('email_address'); ?>"/>
                    <p id="email_error"></p>
                </div>
                <div class="label">
                    <label for="password">Enter a Password<span class="required">*</span></label>
                </div>
                <div class="row">
                    <input type="password" name="password" id="password" required value="<?php echo set_value('password'); ?>"/>
                    <p id="pw_error"></p>
                </div>
                <div class="label">
                    <label for="cpassword">Enter a Password  again<span class="required">*</span></label>
                </div>
                <div class="row">
                    <input type="password" name="cpassword" id="cpassword" required value="<?php echo set_value('cpassword'); ?>"/>
                    <p id="pw_error2"></p>
                </div>
                <div class="row" style="margin-bottom:20px;">
                   <input type="checkbox" name="agree" class="agree" id="agree" /> <label for="agree"><a href="<?php echo site_url('terms-and-conditions');?>">I accept all terms and conditions</a><span class="required">*</span></label>
                </div>
				<input type="submit" name="register" value="Register" class="submit" tabindex="103" />
            </form>
        </div>
                                <div class="clear"></div>
                    </div>
                    <!--End Cotent-->
                
                
            </div>