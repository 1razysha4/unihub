<script>
window.location='<?php echo site_url();?>user/login';
</script>
