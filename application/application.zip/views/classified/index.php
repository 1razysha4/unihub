<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');?>
<div>
<?php echo form_open();?>
<div>
<span><?php echo $university_select;?></span>
<span><input type="submit" name="go" value="Go" /></span>
</div>
<?php echo form_close();?>
</div>