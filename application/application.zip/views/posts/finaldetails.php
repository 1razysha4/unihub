<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');?>
<img src="<?php echo base_url('assets/public/images/step3.gif');?>"  />