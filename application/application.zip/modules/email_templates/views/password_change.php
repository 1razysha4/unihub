Your password has been changed.<br>
New Password:<?php echo $password;?><br />
<a href="<?php echo site_url('login');?>">Click to login to your account</a>

