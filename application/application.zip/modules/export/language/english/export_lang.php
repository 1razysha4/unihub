<?php

$lang['export'] = 'Export';
$lang['linked_objects'] = 'Linked Objects';
$lang['select_object'] = 'Select the object to export';
$lang['select_format'] = 'Select a format';
$lang['single_tables'] = 'Single Tables';

?>
