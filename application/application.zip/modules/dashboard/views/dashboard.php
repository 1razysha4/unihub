<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');?>            
        <ul class="middleNavR">
            <li><a href="#" title="Add an article" class="tipN"><img src="<?php echo base_url().ADMIN_ASSETS;?>/images/icons/middlenav/create.png" alt="" /></a></li>
            <li><a href="#" title="Upload files" class="tipN"><img src="<?php echo base_url().ADMIN_ASSETS;?>/images/icons/middlenav/upload.png" alt="" /></a></li>
            <li><a href="#" title="Add something" class="tipN"><img src="<?php echo base_url().ADMIN_ASSETS;?>/images/icons/middlenav/add.png" alt="" /></a></li>
            <li><a href="#" title="Messages" class="tipN"><img src="<?php echo base_url().ADMIN_ASSETS;?>/images/icons/middlenav/dialogs.png" alt="" /></a><strong>8</strong></li>
            <li><a href="#" title="Check statistics" class="tipN"><img src="<?php echo base_url().ADMIN_ASSETS;?>/images/icons/middlenav/stats.png" alt="" /></a></li>
        </ul>
    
