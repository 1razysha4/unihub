<?php defined('BASEPATH') or die('Direct access is not allowed');
$lang['category'] = 'Category';