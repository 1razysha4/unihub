<?php if (!defined('BASEPATH')) exit('No direct script access allowed');

$lang['branch'] = 'Branches';
$lang['username'] = 'User Name';
$lang['userid'] = 'User ID';
$lang['email'] = 'Email';
$lang['password'] = 'Password';
$lang['repassword'] = 'Re-Password';
$lang['status'] = 'Status';
$lang['usergroup'] = 'User Group';
$lang['ownership'] = 'Ownership';
$lang['this_record_has_been_saved'] = 'User has been saved successfully';
$lang['this_record_has_been_deleted'] = 'User has been deleted successfully';

$lang['groupname'] = 'Group Name';