<?php defined('BASEPATH') or die('Direct access is not allowed');
$lang['category'] = 'Category';
$lang['category_name'] = 'Category Name';
$lang['category_details'] = 'Category Details';