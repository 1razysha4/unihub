	<div class="section_wrapper">

		<h3 class="title_black"><?php echo $this->lang->line('open_tasks'); ?></h3>

		<div class="content toggle no_padding">

			<?php $this->load->view('tasks/table');?>

		</div>

	</div>