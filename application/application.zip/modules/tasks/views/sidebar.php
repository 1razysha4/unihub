<div class="section_wrapper">

	<h3 class="title_white"><?php echo $this->lang->line('tasks'); ?></h3>

	<ul class="quicklinks content toggle">
		<li class="first"><?php echo anchor('tasks', $this->lang->line('view_tasks')); ?></li>
		<li class="last"><?php echo anchor('tasks/form', $this->lang->line('add_task')); ?></li>

	</ul>

</div>