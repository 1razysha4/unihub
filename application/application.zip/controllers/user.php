<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');
class User extends Public_Controller {
	function __construct(){
		parent::__construct();
		$this->load->helper('url');
		$this->load->library('session');
		$this->load->library('template');
		$this->usergroup_id = 3;
	}
	function login(){
        $this->load->library('encrypt');	
		$return = base64_decode($this->input->post('return'));
		$return = ($return)?$return:'dashboard';
		if($this->session->userdata('user_id')) {
                redirect('');
        }
		$data = array();
		$this->load->helper('url');
		$this->template->title('User', 'Login');
		$this->load->helper(array('url', 'form'));
        $this->load->model('users/mdl_auth');
        $this->template->append_metadata('<script src="'.base_url().'assets/public/js/jquery.validate.min.js"></script>');		
		if ($this->mdl_auth->validate_login_front()) {
			if ($user = $this->mdl_auth->auth_front('ci_users', 'email', 'password', $this->input->post('email'), $this->input->post('password'))){
				$object_vars = array();
                // set the session variables
                $this->mdl_auth->set_session($user, $object_vars, array('name'=>$user->name,'user_id'=>$user->user_id,'user_name'=>$user->username,'is_admin'=>$user->is_admin,'created_dt'=>$user->created_dt,'email'=>$user->email,'user_image'=>$user->user_image,'last_login'=>date('Y-m-d H:i:s')));
				redirect($return);
			}
		}else{
			$this->template->set_layout('login');		
			$this->template->build('users/user_login', $data);
		}
	}
	function logout(){
		$this->session->sess_destroy();
        $this->load->helper('url');
		/*$session_data = array('is_admin'=>false);
		$this->session->set_userdata($session_data);*/
		redirect('');
	}
	function register(){
		$this->form_validation->set_rules('email_address',$this->lang->line('email_address'),'trim|required|valid_email|is_unique[ci_users.email]');
		$this->form_validation->set_rules('user_name',$this->lang->line('user_name'),'trim|required|is_unique[ci_users.username]');
		$this->form_validation->set_rules('password',$this->lang->line('password'),'trim|required|matches[cpassword]|md5');
		$this->form_validation->set_rules('cpassword', 'Password Confirmation', 'required');		
		//$this->form_validation->set_rules('recaptcha_response_field','captcha code','required|trim|callback_captcha_check');
		
		if($this->form_validation->run($this)== FALSE){
			$this->template->append_metadata('<script src="'.base_url().'assets/public/js/jquery.validate.min.js"></script>');
			$this->template->build('users/user_login');
		}else{
			$name = $this->input->post('name');
			$username = $this->input->post('user_name');
			$password = $this->input->post('password');
			$email_address = $this->input->post('email_address');
			$occupation = $this->input->post('occupation');
			$activation = md5(md5(time().rand(2, 5)));
			$data = array(
						  'username'=>$username,
						  'name'=>$name,
						  'email'=>$email_address,
						  'password'=>$password,
						  'created_dt'=>date('Y-m-d H:i:s'),
						  'usergroup_id'=>$this->usergroup_id,
						  'activation_key'=>$activation,
						  );
			$this->load->model(array('users/mdl_users'));
			if($this->mdl_users->save($data)){
				$data['user_id'] = $this->db->insert_id();
				$this->load->library('email');
				$config['protocol'] = 'sendmail';
				$config['mailpath'] = '/usr/sbin/sendmail';
				$config['charset'] = 'iso-8859-1';
				$config['wordwrap'] = TRUE;
				$config['mailtype'] = 'html';
				
				$this->email->initialize($config);
				
				$this->email->from(DOMAN_ADMIN_EMAIl, 'Collegewaves');
				$this->email->to($email_address); 
				$message = $this->load->view('email_templates/new_registration',$data,true);
				$this->email->subject('New User Registration');
				$this->email->message($message);	

				$this->email->send();
				$this->session->set_flashdata('success_save',$this->lang->line('user_created_successfully'));
				redirect('');
			}			  
		}
	}
	function captcha_check($code){
		$this->load->helper('recaptchalib');
		$resp = recaptcha_check_answer (RECAPTCHA_PRIVATE_KEY,
	                                $this->input->server('REMOTE_ADDR'),
	                                $this->input->post('recaptcha_challenge_field'),
	                                $this->input->post('recaptcha_response_field'));	
	  if (!$resp->is_valid) {
	  	$this->form_validation->set_message('captcha_check', 'The %s entered is invalid');
		return FALSE;
	  }else{
	  	return TRUE;
	  }
	}
	function activation($user_id){
		$this->load->model(array('users/mdl_users','users/mdl_auth'));
		$activation_key = $this->uri->segment(4);
		if($user_id>0){
			$this->db->from($this->mdl_users->table_name);
			$this->db->where('user_id',$user_id);
			$this->db->where('activation_key',$activation_key);
			$this->db->limit(1);
			$result = $this->db->get();
			$user = $result->row();
			
			$data = array('active'=>1,'activation_key'=>'');
			$this->db->where('user_id',$user_id);
			$this->db->where('activation_key',$activation_key);
			$this->db->update($this->mdl_users->table_name,$data);
			if($this->db->affected_rows()>0){
				$this->session->set_flashdata('success_save','User activated successfully');
				if($user){
					$object_vars = array();
					// set the session variables
					$this->mdl_auth->set_session($user, $object_vars, array('name'=>$user->name,'user_id'=>$user->user_id,'user_name'=>$user->username,'is_admin'=>$user->is_admin,'created_dt'=>$user->created_dt,'email'=>$user->email,'user_image'=>$user->user_image,'last_login'=>date('Y-m-d H:i:s')));
					redirect('dashboard');
				}
			}else{
				$this->session->set_flashdata('success_save','User could not be activated');
			}
			redirect('');
		}
	}
	function recover_password(){
		$this->form_validation->set_rules('email_address',$this->lang->line('email_address'),'trim|required|valid_email|callback_email_check');
		if($this->form_validation->run($this)==FALSE){
			$data = array();
			$this->template->build('users/recover_password',$data);
		}else{
			$this->load->model(array('users/mdl_users'));
			$this->load->helper('string');
			$email_adress = $this->input->post('email_address');
			$password = random_string('alnum', 8);;
			$data = array(
				'password'=>md5($password),
				'modified_dt'=>date('Y-m-d H:i:s')
			);
			$this->load->library('email');
			$config['protocol'] = 'sendmail';
			$config['mailpath'] = '/usr/sbin/sendmail';
			$config['charset'] = 'iso-8859-1';
			$config['wordwrap'] = TRUE;
			$config['mailtype'] = 'html';
			
			$this->email->initialize($config);
			
			$this->email->from(DOMAN_ADMIN_EMAIl, 'Collegewaves');
			$this->email->to($email_adress); 
			$message = $this->load->view('email_templates/password_recovery',array('password'=>$password),true);
			$this->email->subject('Password Recovery');
			$this->email->message($message);	
			
			$this->email->send();
			if($this->db->update($this->mdl_users->table_name,$data,array('email'=>$email_adress),1)){
				$this->session->set_flashdata('success_save',$this->lang->line('password_reset_email_successfully'));
				redirect('login');
			}else{
				$this->session->set_flashdata('custom_warning',$this->lang->line('unable_to_reset_password'));
				redirect('password-recovery');
			}			
		}
	}
	function email_check($email){
		$this->load->model(array('users/mdl_users'));
		$this->db->select('COUNT(user_id) AS total');
		$this->db->from($this->mdl_users->table_name);
		$this->db->where('email',$email);
		$this->db->where('is_admin',1);
		$result = $this->db->get();
		if ($result->row()->total == 0){
			$this->form_validation->set_message('email_check', 'The %s you entered is does not exist.');
			return FALSE;
		}else{
			return TRUE;
		}
	}
	function profile(){
		$password_text = $this->input->post('password');	
		if($this->session->userdata('user_id')==0){
			$this->session->set_flashdata('custom_warning',$this->lang->line('you_are_not_logged'));
			redirect('login?return='.base64_encode($this->uri->uri_string()));
		}
		if($password_text){	
			//$this->form_validation->set_rules('old_password',$this->lang->line('old_password'),'trim|required|md5|callback_password_check');
			$this->form_validation->set_rules('password',$this->lang->line('password'),'trim|required|matches[cpassword]|md5');
			$this->form_validation->set_rules('cpassword', 'Password Confirmation', 'required');		
		}
		$this->form_validation->set_rules('user_id', 'User', 'required');		
		if($this->form_validation->run($this)== FALSE){
		$this->load->model(array('users/mdl_users'));
			$user = $this->mdl_users->getUserDetails($this->session->userdata('user_id'));
			$data = array('user'=>$user);
			$this->template->build('users/profile',$data);
		}else{
			$password = $this->input->post('password');
			$data = array(
					  'modified_dt'=>date('Y-m-d H:i:s')
				     );
			if($password_text){
				$data['password'] = $password; 
			}	     
			$this->load->library('upload');
			$config['upload_path'] = './uploads/users/';
			$config['allowed_types'] = 'gif|jpg|png';
			$config['max_size']	= '102400';
			$config['max_width'] = '1024';
			$config['max_height'] = '768';
			$config['encrypt_name'] = TRUE;
			$config['remove_spaces'] = TRUE;
			$this->upload->initialize($config);

			if( ! $this->upload->do_upload('file_image')){
				$error = array('error' => $this->upload->display_errors());			
			}else{
				$upload_data = $this->upload->data();
				$config = array();
				$config['image_library'] = 'gd2';
				$config['source_image']	= FCPATH.'uploads/users/'.$upload_data['file_name'];
				$config['new_image']	= FCPATH.'uploads/users/thumbs/'.$upload_data['file_name'];
				$config['create_thumb'] = FALSE;
				$config['maintain_ratio'] = FALSE;
				$config['width']	 = 46;
				$config['height']	= 46;
				$config['master_dim'] = 'width';
				
				$this->load->library('image_lib', $config); 
				
				$this->image_lib->resize();
				
				$upload_data = $this->upload->data();
				$data['user_image']	= $upload_data['file_name'];
			}
			$this->load->model(array('users/mdl_users'));
			if($this->mdl_users->save($data,$this->session->userdata('user_id'))){
			$this->load->library('email');	
			$config['protocol'] = 'sendmail';
			$config['mailpath'] = '/usr/sbin/sendmail';
			$config['charset'] = 'iso-8859-1';
			$config['wordwrap'] = TRUE;
			$config['mailtype'] = 'html';
			
			$this->email->initialize($config);
				
			$this->email->from(DOMAN_ADMIN_EMAIl, 'Collegewaves');
			$this->email->to($this->session->userdata('email')); 
			$info = array('password'=>$password_text);
			$message = $this->load->view('email_templates/profile_change',$info,true);
			$this->email->subject('Profile changed');
			$this->email->message($message);	

			$this->email->send();
			$this->session->set_flashdata('success_save',$this->lang->line('profile_saved_sucessfully'));				
			redirect('profile');
			}
		}
	}
	function password_check($old_password){
		
		$username= $this->session->userdata('user_name');
		$this->db->select('COUNT(user_id) AS total');
		$this->db->from('ci_users');
		$this->db->where('username',$username);
		$this->db->where('password',$old_password);		
		$result = $this->db->get();
		
		if ($result->row()->total == 0)
		{
			$this->form_validation->set_message('password_check', '%s entered is incorrect');
			return FALSE;
		}
		else
		{
			return TRUE;
		}
	}
}