<?php
$lang['user'] = 'User';
$lang['save'] = 'Save';
$lang['apply'] = 'Apply';
$lang['cancel'] = 'Cancel';
$lang['dashboad'] = 'Dashboard';
