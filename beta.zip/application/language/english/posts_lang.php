<?php
$lang['user'] = 'User';
$lang['name'] = 'Name';
$lang['log_in'] = 'Log In';