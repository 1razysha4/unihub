<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');
$lang['content_name'] = 'Event Name';
$lang['content_location'] = 'Event Location';
$lang['content_date'] = 'Event Date';
$lang['content_date'] = 'Event Date';
$lang['start_time'] = 'Start Time';
$lang['finish_time'] = 'Finish Time';
$lang['content_organizer'] = 'Event Organizer';
$lang['content_contact_organizer'] = 'Event Contact Organizer';