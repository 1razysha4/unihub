<?php
$lang['user'] = 'User';
$lang['user_name'] = 'User Name';
$lang['name'] = 'Name';
$lang['log_in'] = 'Log In';
$lang['email_address'] = 'Email address';
$lang['password_reset_email_successfully'] = 'Password has been reset successfully. A new password has been sent to your email account.';
$lang['unable_to_reset_password'] = 'Unable to reset password.';
$lang['old_password'] = 'Old Password';
$lang['you_are_not_logged'] = 'You are not logged in.';
$lang['password_changed_successfully'] = 'Your password has been changed successfully.';
$lang['email_or_pw_incorrect'] = 'Email or passwrod is incorrect';
$lang['dashboard'] = 'Dashboard';
$lang['profile_saved_sucessfully'] = 'Profile saved successfully.';
$lang['user_created_successfully'] = 'Your account has been created, verify your acccount through your email';