<?php (defined('BASEPATH')) OR exit('No direct script access allowed');

$config['useragent']='Polique';
$config['protocol'] = 'smtp';
$config['mailpath'] = '/usr/sbin/sendmail';
$config['charset'] = 'iso-8859-1';
$config['mailtype'] = 'html';
$config['wordwrap'] = TRUE;
$config['smtp_host']='localhost';
$config['smtp_user']='';
$config['smtp_pass']='';
$config['smtp_port']='25';
$config['crlf'] = "\r\n";
$config['newline'] = "\r\n";
?>