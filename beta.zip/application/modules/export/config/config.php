<?php (defined('BASEPATH')) OR exit('No direct script access allowed');

$config = array(
	'module_path'			=>	'export',
	'module_name'			=>	'Export',
	'module_description'	=>	'Export data from Codeginter.',
	'module_author'			=>	'Ghanshyam Chaudhari',
	'module_homepage'		=>	'',
	'module_version'		=>	'0.0.1'
);

?>