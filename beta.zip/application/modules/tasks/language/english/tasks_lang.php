<?php (defined('BASEPATH')) OR exit('No direct script access allowed');

$lang['add_task'] = 'Add Task';
$lang['complete_date'] = "Completion Date";
$lang['create_mti'] = 'Create Multi-Task Invoice';
$lang['dashboard_show_open_tasks'] = 'Show Open Tasks on Dashboard';
$lang['open_tasks'] = 'Open Tasks';
$lang['submit_and_create_invoice'] = 'Submit and Create Invoice';
$lang['task_form'] = 'Task Form';
$lang['tasks'] = 'Tasks';
$lang['view_tasks'] = 'View Tasks';

?>