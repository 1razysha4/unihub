<?php ?>
 <ul class="middleNavA">
            <li><a href="#" title="Add an article"><img src="<?php echo base_url().ADMIN_IMAGES;?>/icons/color/order-149.png" alt="" /><span>New tasks</span></a></li>
            <li><a href="#" title="Upload files"><img src="<?php echo base_url().ADMIN_IMAGES;?>/icons/color/issue.png" alt="" /><span>My invoices</span></a></li>
            <li><a href="<?php echo base_url('admin/users/create');?>" title="Add something"><img src="<?php echo base_url().ADMIN_IMAGES;?>/icons/color/hire-me.png" alt="" /><span>Add users</span></a><strong>8</strong></li>
            <li><a href="#" title="Messages"><img src="<?php echo base_url().ADMIN_IMAGES;?>/icons/color/donate.png" alt="" /><span>Donations</span></a></li>
            <li><a href="#" title="Check statistics"><img src="<?php echo base_url().ADMIN_IMAGES;?>/icons/color/config.png" alt="" /><span>Parameters</span></a></li>
        </ul>