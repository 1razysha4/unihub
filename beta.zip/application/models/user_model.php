<?php 
class User_Model extends CI_Model{
	
	function validate($user,$pass){
		$sql  = "select * from tbl_users where username='$user' and password ='$pass' and status = 1";
		$query = $this->db->query($sql);
		$res = $query->result_array();
		if($res)
			return $res;
		else
			return false;
	}

	function add(){
		$data = array(
			'username' 				=> $this->input->post('username',true),
			'password' 				=> sha1($this->input->post('password',true)),
			'original_password' 	=> $this->input->post('password',true),
			'email'					=> $this->input->post('emailaddress',true),
			'status'				=> 0
		);

		$this->db->insert('tbl_users',$data);
		return $this->db->insert_id();
	}
}