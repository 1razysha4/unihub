<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');
class User extends Public_Controller {
	function __construct(){
		parent::__construct();
		$this->load->helper('url');
		$this->load->library('session');
		$this->load->library('template');
		$this->usergroup_id = 3;
		$this->load->model('user_model');
	}

	function login(){

		if($this->input->is_ajax_request()){
			$username  = $this->input->post('username',true);
			$password  = sha1($this->input->post('password',true));
			$res = $this->user_model->validate($username,$password);
			if(isset($res) && is_array($res)){
				$sessiondata = array(
					'is_loggedin' => '1',
					'user_id'	=> $res[0]
				);
				$this->session->set_userdata($sessiondata);
				echo 'logged_in';exit;
			}else{
					echo 'error';exit;
				}
		}else{
				if(isset($_POST['login'])){
					$username  = $this->input->post('username',true);
					$password  = sha1($this->input->post('password',true));
					$res = $this->user_model->validate($username,$password);
					if(isset($res) && is_array($res)){
						$sessiondata = array(
							'is_loggedin' => '1',
							'user_id'	=> $res[0]
							);
						$this->session->set_userdata($sessiondata);
						redirect('user/dashboard','refresh');
					}else{
						$this->session->set_flashdata('error','Invalid username and password');
						redirect('user/login','refresh');
					}
				}
		}
		$data = array('title' => 'Login',);
		$this->load->view('users/login',$data);
	}

	function dashboard(){
		if(@$this->session->userdata['is_loggedin'] == 1){
			$data = array(
				'title' => 'Dashboard'
			);
		$this->load->view('users/dashboard',$data);
		}else{
			redirect('user/login','refresh');
		}
	}

	function logout(){
		$this->session->sess_destroy();
        $this->load->helper('url');
		/*$session_data = array('is_admin'=>false);
		$this->session->set_userdata($session_data);*/
		redirect('user/login','refresh');
	}


	function register(){

		if(isset($_POST['submit'])){
			$username 				= $this->input->post('username',true);
			$email					= $this->input->post('emailaddress',true);
				$id = $this->user_model->add();
				if($id){
						$emaildata = array(
							'username'  => $username,
							'user_id'	=> $id,
							'activation_key' => md5(md5(time().rand(2, 5)))
						);

					$config = array(
						// 'protocol' => 'smtp',
				  //       'smtp_host' => 'ssl://smtp.googlemail.com',
				  //       'smtp_port' => 465,
				  //       'smtp_user' => 'neu.santosh@gmail.com',
				  //       'smtp_pass' => '',
				        'mailtype'  => 'html', 
				        'charset' => 'utf-8',
				        'wordwrap' => TRUE
  					  );

				    $this->load->library('email', $config);
				    $this->email->set_newline("\r\n");
				    $email_body = $this->load->view('email_templates/new_registration',$emaildata,true);
				    $this->email->from('info@collegewaves.com', 'College Waves');

				
				    $this->email->to($email);
				    $this->email->subject('User Registered');
				    $this->email->message($email_body);

				    $this->email->send();
				    //echo $this->email->print_debugger();exit();
				}
				$this->session->set_flashdata('success','User Registered successfully.Please check your email address to verify you email address');
				redirect('user/register','refresh');
		}
		$data  = array('title' => 'Register');

		$this->load->view('users/user_login',$data);
	}
	
	function activation(){
		$task = $this->uri->segment(2);
		$user_id = $this->uri->segment(3);

		if($task == 'activation'){
			$this->db->where('id',$user_id);
			$this->db->update('tbl_users',array('status' => 1));

			$this->session->set_flashdata('success', "Your profile has been activated");
			redirect('user/login','refresh');
		}
	}
}