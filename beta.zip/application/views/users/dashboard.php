<?php $this->load->view('includes/header');?>
	<div class="container">
		<div class="row">	
					<div class="col-md-12">
						<h3 class="section-title">Welcome to User Dashboard.</h3>
						<a href="<?php echo site_url();?>user/logout">Logout</a>
					<div>
				</div>
			</div>
		</div>
	</div>
<?php $this->load->view('includes/footer');?>