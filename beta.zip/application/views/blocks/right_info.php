<?php (defined('BASEPATH')) OR exit('No direct script access allowed');?>
<div class="grid_7 omega">
	<div class="sidebar">
    <!--Start sidebar_widget-->
<div class="sidebar_widget">
    <div class="contact_widget">
        <div class="subscribe_form" style="margin-bottom:20px;">
            <h5 class="contact_header">Meet The Founders</h5>
            <div class="form_element1">
                <ul id="products" class="list clearfix">
                                                                                                <!-- row 1 -->
                                                    <li class="thumbnail">
                                                        <section class="thumbs1">
                                                                                                                            <a href=""><img src="" width="55" height="55" class="postimg " alt="Post Image"></a> 
                                                                                                                            
             <section class="thumb_item">
                                                                                                                                        
               <div class="clear" style="display: none;"></div>
                                                                
                                                            </section>
                                                        </section>
                                                        <section class="contents">
                                                           
                                                            <section class="grid_content">
                                                             <h6 class="title1"><a href="" rel="bookmark" title="Permanent Link to Logo Printing on T-shirts, Mugs, Corporate Bags">
                                                               Mr.Saroj Nepal                                                                </a></h6><p class="founder">
                                                            E-mail: tansen@collegewaves.com
                                                            </p>
</section>
                                                            <div class="clear" style="display: none;"></div>
                                                           

                                                        </section>
                                                    </li>
                                                    <li class="thumbnail">
                                                        <section class="thumbs1">
                                                                                                                            <a href=""><img src="" width="55" height="55" class="postimg " alt="Post Image"></a> 
                                                                                                                            
             <section class="thumb_item">
                                                                                                                                        
               <div class="clear" style="display: none;"></div>
                                                                
                                                            </section>
                                                        </section>
                                                        <section class="contents">
                                                           
                                                            <section class="grid_content">
                                                             <h6 class="title1"><a href="" rel="bookmark" title="Permanent Link to Logo Printing on T-shirts, Mugs, Corporate Bags">
                                                               Martin Guptill                                                               </a></h6><p class="founder">
                                                            E-mail: martin@collegewaves.com
                                                            </p>
</section>
                                                            <div class="clear" style="display: none;"></div>
                                                           

                                                        </section>
                                                    </li>

                                                                                            </ul>
               
            </div>
        </div>
        
        
        <div class="subscribe_form">
            <h5 class="contact_header">CollegeWaves Team</h5>
            <div class="form_element1">
                <ul id="products" class="list clearfix">
                                                                                                <!-- row 1 -->
                                                    <li class="thumbnail">
                                                        <section class="thumbs1">
                                                                                                                            <a href=""><img src="" width="55" height="55" class="postimg " alt="Post Image"></a> 
                                                                                                                            
             <section class="thumb_item">
                                                                                                                                        
               <div class="clear" style="display: none;"></div>
                                                                
                                                            </section>
                                                        </section>
                                                        <section class="contents">
                                                           
                                                            <section class="grid_content">
                                                             <h6 class="title1"><a href="ads-details.php" rel="bookmark" title="Permanent Link to Logo Printing on T-shirts, Mugs, Corporate Bags">
                                                               Mark Price                                                                </a></h6><p class="founder">
                                                            E-mail: mark@collegewaves.com
                                                            </p>
</section>
                                                            <div class="clear" style="display: none;"></div>
                                                           

                                                        </section>
                                                    </li>
                                                    <li class="thumbnail">
                                                        <section class="thumbs1">
                                                                                                                            <a href=""><img src="" width="55" height="55" class="postimg " alt="Post Image"></a> 
                                                                                                                            
             <section class="thumb_item">
                                                                                                                                        
               <div class="clear" style="display: none;"></div>
                                                                
                                                            </section>
                                                        </section>
                                                        <section class="contents">
                                                           
                                                            <section class="grid_content">
                                                             <h6 class="title1"><a href="ads-details.php" rel="bookmark" title="Permanent Link to Logo Printing on T-shirts, Mugs, Corporate Bags">
                                                               Peter Bretley                                                              </a></h6><p class="founder">
                                                            E-mail: martin@collegewaves.com
                                                            </p>
</section>
                                                            <div class="clear" style="display: none;"></div>
                                                           

                                                        </section>
                                                    </li>
                                                    
                                                    <li class="thumbnail">
                                                        <section class="thumbs1">
                                                                                                                            <a href=""><img src="" width="55" height="55" class="postimg " alt="Post Image"></a> 
                                                                                                                            
             <section class="thumb_item">
                                                                                                                                        
               <div class="clear" style="display: none;"></div>
                                                                
                                                            </section>
                                                        </section>
                                                        <section class="contents">
                                                           
                                                            <section class="grid_content">
                                                             <h6 class="title1"><a href="" rel="bookmark" title="Permanent Link to Logo Printing on T-shirts, Mugs, Corporate Bags">
                                                               Will Smith                                                               </a></h6><p class="founder">
                                                            E-mail: martin@collegewaves.com
                                                            </p>
</section>
                                                            <div class="clear" style="display: none;"></div>
                                                           

                                                        </section>
                                                    </li>

                                                                                            </ul>
               
            </div>
        </div>
    </div>
</div>

      
            </div>
</div>