<!DOCTYPE html>
<html>
	<head>
		<title><?php echo $template['title']; ?></title>
		<?php echo $template['metadata']; ?>
	</head>
	<body>
		<h1><?php echo $template['title']; ?></h1>
		<?php echo $template['body']; ?>
	</body>
</html>